import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get android => const FirebaseOptions(
        apiKey: 'AIzaSyDI9-kjAeHrn7GicRWOJrjuKS9s2XReQmE',
        appId: '1:558049211532:android:8ba97bec4cac78e30137a9',
        messagingSenderId: '558049211532',
        projectId: 'iot-project-dca84',
        databaseURL:
            'https://iot-project-dca84-default-rtdb.asia-southeast1.firebasedatabase.app/',
      );
}
