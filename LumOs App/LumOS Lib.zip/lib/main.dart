import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'mqtt_service.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'firebase_options.dart';

/* ===================== MAIN ===================== */

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.android,
  );
  runApp(const MyApp());
}

/* ===================== DATA ===================== */

enum LampMode { manual, timer, auto }

class DailyStat {
  final int day;
  final double kwh;
  DailyStat({required this.day, required this.kwh});
}

class DeviceData {
  double v = 0;
  double p = 0;
  bool isOn = false;
  DateTime? lastPowerChange;

  LampMode mode = LampMode.manual;

  int r = 255;
  int g = 255;
  int b = 255;
  int br = 100;
}

class PowerPoint {
  final DateTime time;
  final double value;
  PowerPoint(this.time, this.value);
}

final devicesNotifier = ValueNotifier<Map<int, DeviceData>>({
  1: DeviceData(),
  2: DeviceData(),
});

final powerGraphNotifier = ValueNotifier<List<PowerPoint>>([]);

/* ===================== APP ===================== */

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late MqttService mqtt;
  bool connected = false;

  Future<void> _reconnect() async {
    mqtt.disconnect();
    await Future.delayed(const Duration(milliseconds: 200));
    _connect();
  }

  late Future<List<DailyStat>> lamp1DailyFuture;
  late Future<List<DailyStat>> lamp2DailyFuture;

  static const host = '98.90.36.78';
  static const username = 'admin';
  static const password = 'rahasia123';

  final topics = {
    1: {
      'v': 'Lamp1/listrik/tegangan',
      'p': 'Lamp1/listrik/daya',
      'c': 'Lamp1/lampu/set',
    },
    2: {
      'v': 'Lamp2/listrik/tegangan',
      'p': 'Lamp2/listrik/daya',
      'c': 'Lamp2/lampu/set',
    },
  };

  @override
  void initState() {
    super.initState();

    lamp1DailyFuture = fetchMonthlyStats(1);
    lamp2DailyFuture = fetchMonthlyStats(2);

    mqtt = MqttService(
      host: host,
      port: 1883,
      username: username,
      password: password,
      clientId: 'flutter_${DateTime.now().millisecondsSinceEpoch}',
    );

    _connect();
  }

  Future<void> _connect() async {
    connected = await mqtt.connect();
    if (!connected) return;

    for (var t in topics.values) {
      mqtt.subscribe(t['v']!);
      mqtt.subscribe(t['p']!);
    }

    mqtt.onMessage(_onMessage);
    setState(() {});
  }

  /* ===================== MQTT ===================== */

  void _onMessage(String topic, String payload) {
    final id = topic.startsWith('Lamp1')
        ? 1
        : topic.startsWith('Lamp2')
            ? 2
            : 0;
    if (id == 0) return;

    final dev = devicesNotifier.value[id]!;
    final val = double.tryParse(payload) ?? 0;

    if (topic.endsWith('tegangan')) dev.v = val;

    if (topic.endsWith('daya')) {
      dev.p = val;
      final now = DateTime.now();
      dev.lastPowerChange ??= now;

      if (!dev.isOn &&
          val > 1.0 &&
          now.difference(dev.lastPowerChange!) >
              const Duration(milliseconds: 800)) {
        dev.isOn = true;
        dev.lastPowerChange = now;
      }

      if (dev.isOn &&
          val < 0.3 &&
          now.difference(dev.lastPowerChange!) >
              const Duration(milliseconds: 800)) {
        dev.isOn = false;
        dev.lastPowerChange = now;
      }

      powerGraphNotifier.value = [
        ...powerGraphNotifier.value,
        PowerPoint(now, val),
      ].takeLast(30).toList();
    }

    devicesNotifier.value = {...devicesNotifier.value};
  }

  /* ===================== COMMANDS ===================== */

  void _toggle(int id, bool on) {
    final dev = devicesNotifier.value[id]!;
    dev.mode = LampMode.manual;

    mqtt.publish(
      topics[id]!['c']!,
      jsonEncode(
        on
            ? {
                "merah": dev.r,
                "hijau": dev.g,
                "biru": dev.b,
                "terang": dev.br,
              }
            : {
                "merah": 0,
                "hijau": 0,
                "biru": 0,
                "terang": 0,
              },
      ),
    );

    devicesNotifier.value = {...devicesNotifier.value};
  }

  void _sendColor(int id, int r, int g, int b, int br) {
    final dev = devicesNotifier.value[id]!;
    dev
      ..r = r
      ..g = g
      ..b = b
      ..br = br
      ..mode = LampMode.manual;

    mqtt.publish(
      topics[id]!['c']!,
      jsonEncode({
        "merah": r,
        "hijau": g,
        "biru": b,
        "terang": br,
      }),
    );

    devicesNotifier.value = {...devicesNotifier.value};
  }

  void _sendTimer(
    int id,
    TimeOfDay start,
    TimeOfDay end,
    int r,
    int g,
    int b,
    int dim,
  ) {
    final dev = devicesNotifier.value[id]!;
    dev
      ..r = r
      ..g = g
      ..b = b
      ..br = dim
      ..mode = LampMode.timer;

    mqtt.publish(
      topics[id]!['c']!,
      jsonEncode({
        "set_start_h": start.hour,
        "set_start_m": start.minute,
        "set_end_h": end.hour,
        "set_end_m": end.minute,
        "set_r": r,
        "set_g": g,
        "set_b": b,
        "set_dim": dim,
      }),
    );

    devicesNotifier.value = {...devicesNotifier.value};
  }

  void _sendAuto(int id) {
    devicesNotifier.value[id]!.mode = LampMode.auto;

    mqtt.publish(
      topics[id]!['c']!,
      jsonEncode({
        "set_start_h": -1,
        "set_end_h": -1,
      }),
    );

    devicesNotifier.value = {...devicesNotifier.value};
  }

  /* ===================== FIREBASE ===================== */

  Future<List<DailyStat>> fetchMonthlyStats(int lampId) async {
    final now = DateTime.now();
    final key = '${now.month.toString().padLeft(2, '0')}-${now.year}';
    final ref = FirebaseDatabase.instance.ref('Statistik/Lamp$lampId/$key');

    final snap = await ref.get();
    if (!snap.exists) return [];

    final data = Map<String, dynamic>.from(snap.value as Map);
    final result = <DailyStat>[];

    for (final e in data.entries) {
      result.add(DailyStat(
        day: int.parse(e.key.replaceAll('Tgl-', '')),
        kwh: (e.value['kwh'] ?? 0).toDouble(),
      ));
    }

    result.sort((a, b) => a.day.compareTo(b.day));
    return result;
  }

  /* ===================== UI ===================== */

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('LumOS'),
          actions: [
            Icon(
              connected ? Icons.cloud_done : Icons.cloud_off,
            ),
            IconButton(
              icon: const Icon(Icons.refresh),
              tooltip: 'Reconnect MQTT',
              onPressed: _reconnect,
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            ValueListenableBuilder(
              valueListenable: devicesNotifier,
              builder: (_, map, __) => Column(
                children: [
                  LampCard(
                    id: 1,
                    data: map[1]!,
                    onToggle: _toggle,
                    onColor: _sendColor,
                    onTimer: _sendTimer,
                    onAuto: _sendAuto,
                  ),
                  LampCard(
                    id: 2,
                    data: map[2]!,
                    onToggle: _toggle,
                    onColor: _sendColor,
                    onTimer: _sendTimer,
                    onAuto: _sendAuto,
                  ),
                  const PowerGraphCard(),
                ],
              ),
            ),
            DailyKwhGraphCard(
              title: 'Lamp 1 – Daily kWh',
              future: lamp1DailyFuture,
            ),
            DailyKwhGraphCard(
              title: 'Lamp 2 – Daily kWh',
              future: lamp2DailyFuture,
            ),
          ],
        ),
      ),
    );
  }
}

/* ===================== LAMP CARD ===================== */

class LampCard extends StatelessWidget {
  final int id;
  final DeviceData data;
  final void Function(int, bool) onToggle;
  final void Function(int, int, int, int, int) onColor;
  final void Function(
    int,
    TimeOfDay,
    TimeOfDay,
    int,
    int,
    int,
    int,
  ) onTimer;
  final void Function(int) onAuto;

  const LampCard({
    super.key,
    required this.id,
    required this.data,
    required this.onToggle,
    required this.onColor,
    required this.onTimer,
    required this.onAuto,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /* ================= LEFT ================= */
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Lamp $id',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('Voltage: ${data.v.toStringAsFixed(1)} V'),
                  Text('Power: ${data.p.toStringAsFixed(1)} W'),
                  const SizedBox(height: 12),
                  ToggleButtons(
                    isSelected: [
                      data.mode == LampMode.manual,
                      data.mode == LampMode.timer,
                      data.mode == LampMode.auto,
                    ],
                    onPressed: (i) {
                      if (i == 2) onAuto(id);
                    },
                    children: const [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Text('Manual'),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 6),
                        child: Text('Timer'),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 4),
                        child: Text('Auto'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),

/* ================= RIGHT ================= */
            Column(
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: 70,
                      child: ElevatedButton(
                        onPressed: () => onToggle(id, true),
                        child: const Text('ON'),
                      ),
                    ),
                    const SizedBox(width: 6),
                    SizedBox(
                      width: 75,
                      child: ElevatedButton(
                        onPressed: () => onToggle(id, false),
                        child: const Text('OFF'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                IconButton(
                  tooltip: 'Color Picker',
                  icon: const Icon(Icons.palette),
                  onPressed: () => _colorPicker(context),
                ),
                IconButton(
                  tooltip: 'Timer',
                  icon: const Icon(Icons.schedule),
                  onPressed: () => _timerPicker(context),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _colorPicker(BuildContext context) {
    int r = data.r, g = data.g, b = data.b, br = data.br;

    void applyPreset(int pr, int pg, int pb, int pbr) {
      r = pr;
      g = pg;
      b = pb;
      br = pbr;
    }

    showModalBottomSheet(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (_, setSB) => Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _slider('R', 255, r, (v) => setSB(() => r = v)),
              _slider('G', 255, g, (v) => setSB(() => g = v)),
              _slider('B', 255, b, (v) => setSB(() => b = v)),
              _slider('Dim', 100, br, (v) => setSB(() => br = v)),
              const SizedBox(height: 12),

              /* ================= PRESETS ================= */
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(80, 140, 255, 80);
                    }),
                    child: const Text('🧊 Arctic Focus'),
                  ),
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(255, 140, 40, 80);
                    }),
                    child: const Text('🎨 Amber Muse'),
                  ),
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(60, 200, 90, 70);
                    }),
                    child: const Text('🌿 Verdant Calm'),
                  ),
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(255, 60, 60, 85);
                    }),
                    child: const Text('🔥 Crimson Surge'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  onColor(id, r, g, b, br);
                  Navigator.pop(context);
                },
                child: const Text('Send'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _timerPicker(BuildContext context) {
    TimeOfDay start = const TimeOfDay(hour: 18, minute: 0);
    TimeOfDay end = const TimeOfDay(hour: 6, minute: 0);

    int r = data.r, g = data.g, b = data.b, br = data.br;

    void applyPreset(int pr, int pg, int pb, int pbr) {
      r = pr;
      g = pg;
      b = pb;
      br = pbr;
    }

    showModalBottomSheet(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (_, setSB) => Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              /* ================= TIME ================= */
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      child: Text('Start: ${start.format(context)}'),
                      onPressed: () async {
                        final t = await showTimePicker(
                          context: context,
                          initialTime: start,
                        );
                        if (t != null) setSB(() => start = t);
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      child: Text('End: ${end.format(context)}'),
                      onPressed: () async {
                        final t = await showTimePicker(
                          context: context,
                          initialTime: end,
                        );
                        if (t != null) setSB(() => end = t);
                      },
                    ),
                  ),
                ],
              ),

              /* ================= COLOR ================= */
              _slider('R', 255, r, (v) => setSB(() => r = v)),
              _slider('G', 255, g, (v) => setSB(() => g = v)),
              _slider('B', 255, b, (v) => setSB(() => b = v)),
              _slider('Dim', 100, br, (v) => setSB(() => br = v)),
              const SizedBox(height: 12),

              /* ================= PRESETS ================= */
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(80, 140, 255, 80);
                    }),
                    child: const Text('🧊 Arctic Focus'),
                  ),
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(255, 140, 40, 80);
                    }),
                    child: const Text('🎨 Amber Muse'),
                  ),
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(60, 200, 90, 70);
                    }),
                    child: const Text('🌿 Verdant Calm'),
                  ),
                  ElevatedButton(
                    onPressed: () => setSB(() {
                      applyPreset(255, 60, 60, 85);
                    }),
                    child: const Text('🔥 Crimson Surge'),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              /* ================= SEND ================= */
              ElevatedButton(
                onPressed: () {
                  onTimer(id, start, end, r, g, b, br);
                  Navigator.pop(context);
                },
                child: const Text('Set Timer'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _slider(String label, int max, int val, ValueChanged<int> cb) {
    return Row(
      children: [
        SizedBox(width: 60, child: Text(label)),
        Expanded(
          child: Slider(
            min: 0,
            max: max.toDouble(),
            value: val.toDouble(),
            onChanged: (v) => cb(v.toInt()),
          ),
        ),
        SizedBox(width: 40, child: Text('$val')),
      ],
    );
  }
}

/* ===================== GRAPHS ===================== */

class PowerGraphCard extends StatelessWidget {
  const PowerGraphCard({super.key});
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<List<PowerPoint>>(
      valueListenable: powerGraphNotifier,
      builder: (_, points, __) {
        if (points.isEmpty) return const Text('Waiting for data...');
        return SizedBox(
          height: 200,
          child: LineChart(
            LineChartData(
              titlesData: FlTitlesData(show: false),
              borderData: FlBorderData(show: false),
              lineBarsData: [
                LineChartBarData(
                  spots: points
                      .asMap()
                      .entries
                      .map(
                        (e) => FlSpot(
                          e.key.toDouble(),
                          e.value.value,
                        ),
                      )
                      .toList(),
                  isCurved: true,
                  dotData: FlDotData(show: false),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

List<FlSpot> dailyStatsToSpots(List<DailyStat> stats) =>
    stats.map((s) => FlSpot(s.day.toDouble(), s.kwh)).toList();

class DailyKwhGraphCard extends StatelessWidget {
  final String title;
  final Future<List<DailyStat>> future;

  const DailyKwhGraphCard({
    super.key,
    required this.title,
    required this.future,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: FutureBuilder<List<DailyStat>>(
          future: future,
          builder: (_, snapshot) {
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Text('No data available');
            }

            final stats = snapshot.data!;
            return Column(
              children: [
                Text(title),
                SizedBox(
                  height: 200,
                  child: LineChart(
                    LineChartData(
                      lineBarsData: [
                        LineChartBarData(
                          spots: dailyStatsToSpots(stats),
                          isCurved: true,
                          dotData: FlDotData(show: true),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/* ===================== UTILS ===================== */

extension TakeLast<T> on Iterable<T> {
  Iterable<T> takeLast(int n) => skip(length > n ? length - n : 0);
}
