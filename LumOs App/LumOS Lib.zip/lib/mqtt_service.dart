// lib/mqtt_service.dart
import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:mqtt_client/mqtt_browser_client.dart';

/// Simple cross-platform MQTT service
class MqttService {
  final String host;
  final int port;
  final String username;
  final String password;
  final String clientId;

  MqttServerClient? _serverClient;
  MqttBrowserClient? _browserClient;
  StreamSubscription? _updatesSub;

  void Function(String topic, String payload)? _messageHandler;

  MqttService({
    required this.host,
    this.port = 1883,
    required this.username,
    required this.password,
    required this.clientId,
  });

  bool get _isWeb => kIsWeb;

  /// Connect to broker
  Future<bool> connect({Duration timeout = const Duration(seconds: 10)}) async {
    if (_isWeb) {
      return _connectWeb(timeout: timeout);
    } else {
      return _connectServer(timeout: timeout);
    }
  }

  // ================= WEB (WebSocket, SSL handled by browser) =================
  Future<bool> _connectWeb(
      {Duration timeout = const Duration(seconds: 10)}) async {
    final wsUrl = 'ws://$host:$port/mqtt'; // ⚠️ NON-SSL WebSocket
    _browserClient = MqttBrowserClient(wsUrl, clientId);

    _browserClient!.logging(on: false);
    _browserClient!.setProtocolV311();
    _browserClient!.keepAlivePeriod = 20;

    _browserClient!.onConnected = () => print('[MQTT-Web] connected');
    _browserClient!.onDisconnected = () => print('[MQTT-Web] disconnected');
    _browserClient!.onSubscribed = (t) => print('[MQTT-Web] subscribed $t');

    _browserClient!.connectionMessage = MqttConnectMessage()
        .withClientIdentifier(clientId)
        .authenticateAs(username, password)
        .startClean();

    try {
      await _browserClient!.connect(username, password).timeout(timeout);
    } catch (e) {
      print('[MQTT-Web] connect error: $e');
      _browserClient?.disconnect();
      return false;
    }

    _updatesSub?.cancel();
    _updatesSub = _browserClient?.updates?.listen(_onEvents);

    return _browserClient?.connectionStatus?.state ==
        MqttConnectionState.connected;
  }

  // ================= MOBILE / DESKTOP (PLAIN MQTT, NO SSL) =================
  Future<bool> _connectServer(
      {Duration timeout = const Duration(seconds: 10)}) async {
    _serverClient = MqttServerClient.withPort(host, clientId, port);

    // 🔴 IMPORTANT: SSL OFF
    _serverClient!.secure = false;
    _serverClient!.useWebSocket = false;

    _serverClient!.setProtocolV311();
    _serverClient!.keepAlivePeriod = 20;
    _serverClient!.logging(on: false);

    _serverClient!.onConnected = () => print('[MQTT] connected');
    _serverClient!.onDisconnected = () => print('[MQTT] disconnected');
    _serverClient!.onSubscribed = (t) => print('[MQTT] subscribed $t');

    _serverClient!.connectionMessage = MqttConnectMessage()
        .withClientIdentifier(clientId)
        .authenticateAs(username, password)
        .startClean();

    try {
      await _serverClient!.connect(username, password).timeout(timeout);
    } catch (e) {
      print('[MQTT] connect error: $e');
      _serverClient?.disconnect();
      return false;
    }

    _updatesSub?.cancel();
    _updatesSub = _serverClient?.updates?.listen(_onEvents);

    return _serverClient?.connectionStatus?.state ==
        MqttConnectionState.connected;
  }

  // ================= INTERNAL EVENT HANDLER =================
  void _onEvents(List<MqttReceivedMessage<MqttMessage>> events) {
    for (final event in events) {
      final payload = event.payload;
      if (payload is MqttPublishMessage) {
        final message =
            MqttPublishPayload.bytesToStringAsString(payload.payload.message);
        _messageHandler?.call(event.topic, message);
      }
    }
  }

  // ================= PUBLIC API =================
  void subscribe(String topic, {MqttQos qos = MqttQos.atMostOnce}) {
    _isWeb
        ? _browserClient?.subscribe(topic, qos)
        : _serverClient?.subscribe(topic, qos);
  }

  void onMessage(void Function(String topic, String payload) handler) {
    _messageHandler = handler;
  }

  void publish(String topic, String payload,
      {MqttQos qos = MqttQos.atMostOnce, bool retain = false}) {
    final builder = MqttClientPayloadBuilder()..addString(payload);

    _isWeb
        ? _browserClient?.publishMessage(topic, qos, builder.payload!,
            retain: retain)
        : _serverClient?.publishMessage(topic, qos, builder.payload!,
            retain: retain);
  }

  void disconnect() {
    _updatesSub?.cancel();
    _updatesSub = null;
    _messageHandler = null;

    if (_isWeb) {
      _browserClient?.disconnect();
      _browserClient = null;
    } else {
      _serverClient?.disconnect();
      _serverClient = null;
    }
  }

  bool get isConnected => _isWeb
      ? _browserClient?.connectionStatus?.state == MqttConnectionState.connected
      : _serverClient?.connectionStatus?.state == MqttConnectionState.connected;
}
